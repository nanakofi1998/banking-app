import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-attorney-details',
  templateUrl: './attorney-details.component.html',
  styleUrls: ['./attorney-details.component.scss']
})
export class AttorneyDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
