import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-case-study-details',
  templateUrl: './case-study-details.component.html',
  styleUrls: ['./case-study-details.component.scss']
})
export class CaseStudyDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
