import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-attorney',
  templateUrl: './attorney.component.html',
  styleUrls: ['./attorney.component.scss']
})
export class AttorneyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
