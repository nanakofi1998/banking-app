import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-practice-details',
  templateUrl: './practice-details.component.html',
  styleUrls: ['./practice-details.component.scss']
})
export class PracticeDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
